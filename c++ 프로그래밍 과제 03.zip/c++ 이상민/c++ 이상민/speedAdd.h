#include <cstdio>
#include <cstdlib>
#include <ctime>
extern void playAdd();
