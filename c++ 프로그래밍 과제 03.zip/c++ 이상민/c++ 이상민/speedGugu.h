#include <cstdio>
#include <cstdlib>
#include <ctime>
extern void playGugu();
